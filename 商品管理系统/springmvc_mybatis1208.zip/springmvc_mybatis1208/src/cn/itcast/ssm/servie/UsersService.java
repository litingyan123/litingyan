package cn.itcast.ssm.servie;

import cn.itcast.ssm.po.Users;

public interface UsersService {
	public  Users CheckLogin(Users users);
}
