package cn.itcast.ssm.po;

public class ItemsCustom extends Items{

}
