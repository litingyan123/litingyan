package cn.itcast.ssm.interceptor;

public class HandlerInterceptor2 {

}
