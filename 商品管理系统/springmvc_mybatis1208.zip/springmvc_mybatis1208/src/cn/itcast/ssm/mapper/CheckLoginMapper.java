package cn.itcast.ssm.mapper;

import cn.itcast.ssm.po.Users;

public interface CheckLoginMapper {
	public Users CheckLogin(Users users);

}
